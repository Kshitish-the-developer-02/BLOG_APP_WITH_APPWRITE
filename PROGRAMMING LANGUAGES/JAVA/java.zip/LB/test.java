
public class test {
    public static void main(String[] args) {

        c2 obj = new c2();
        obj.input_x(10);
        obj.display_x();

        obj.input_y(20);
        obj.display();

    }

}
