public class si1 {
    int x=10;
    void display()
    {
        System.out.println(x);
    }
    
}

