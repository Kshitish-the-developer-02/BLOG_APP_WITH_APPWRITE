#include <stdio.h>
#include <string.h>

#define MAX_STUDENTS 5

struct student {
    char name[100];
    int roll;
    float marks;
};

int main() {
    struct student students[MAX_STUDENTS];
    int i, j;
    
    // Input information for each student
    for (i = 0; i < MAX_STUDENTS; i++) {
        printf("Enter name, roll and marks for student %d:\n", i+1);
        scanf("%s %d %f", students[i].name, &students[i].roll, &students[i].marks);
    }
    
    // Sort students based on ascending order of marks
    for (i = 0; i < MAX_STUDENTS-1; i++) {
        for (j = 0; j < MAX_STUDENTS-i-1; j++) {
            if (students[j].marks > students[j+1].marks) {
                struct student temp = students[j];
                students[j] = students[j+1];
                students[j+1] = temp;
            }
        }
    }
    
    // Print students' names based on ascending order of marks
    printf("Students' names in ascending order of marks:\n");
    for (i = 0; i < MAX_STUDENTS; i++) {
        printf("%s\n", students[i].name);
    }
return 0;    
}
