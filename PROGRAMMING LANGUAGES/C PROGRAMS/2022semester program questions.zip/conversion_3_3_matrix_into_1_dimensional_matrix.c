#include <stdio.h>

int main()
{

    int matrix[10][10];
    int m, n;
    int array[m * n];
    int i, j, k = 0;
    printf("enter number of row:   ");
    scanf("%d", &m);
    printf("enter number of column :  ");
    scanf("%d", &n);

    printf("\nenter values into the matrix:\n");
    for (i = 0; i < m; i++)
    {
        for (j = 0; j < n; j++)
        {

            scanf("%d", &matrix[i][j]);
        }
    }
    printf("\noriginal matrix is:\n");
    for (i = 0; i < m; i++)
    {
        for (j = 0; j < n; j++)
        {
            printf("%d\t", matrix[i][j]);
        }
        printf("\n");
    }

    for (i = 0; i < m; i++)
    {
        for (j = 0; j < n; j++)
        {
            array[k] = matrix[i][j];
            k++;
        }
    }

    printf("1D Array: ");
    for (i = 0; i < m * n; i++)
    {
        printf("%d ", array[i]);
    }
    return 0;
}