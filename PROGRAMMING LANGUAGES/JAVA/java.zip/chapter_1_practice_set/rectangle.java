public class rectangle{
    int length;
    int width;
    void input_data(int x,int y){
        length=x;
        width=y;
    }
    int area_of_rectangle(){
        int area;
        area=length*width;
        return area;
    }
}

public class rectangle_main{
    public static void main(String[] args) {
        
    }
}