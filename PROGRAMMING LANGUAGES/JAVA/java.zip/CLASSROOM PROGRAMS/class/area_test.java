public class area_test {
    public static void main(String[] args) {
        area_of_circle area=new area_of_circle();
        double res=area.input(5.0);
        System.out.println("area of the circle is= "+res);

    }
    
}
