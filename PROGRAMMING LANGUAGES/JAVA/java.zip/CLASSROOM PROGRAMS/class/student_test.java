public class student_test {
    public static void main(String[] args) {
        stdent stu1 = new stdent();
        stu1.input("Kshitish", 52, "1st", 420);
        stu1.display();

        stdent stu2 = new stdent();
        stu2.input("Akash", 53, "1st", 425);
        stu2.display();

    }

}
