public class test_private {
    private int x=10;
    int get_x(){
        return x;
    }
    
}
