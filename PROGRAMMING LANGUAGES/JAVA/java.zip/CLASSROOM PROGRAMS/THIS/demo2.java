public class demo2 {
    int p;
    int q;
    demo2(int p,int q){
        this.p=p;
        this.q=q;
    }
    void display(){
        System.out.println(p+" "+q);
    }
    
}
