public class testsi {
    public static void main(String[] args) {
        si2 obj=new si2();

        obj.display();
        obj.display();
    }
    
}
