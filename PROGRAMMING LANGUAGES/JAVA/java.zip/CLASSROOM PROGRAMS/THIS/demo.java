
public class demo {
    int p;
    int q;

    void input(int p, int q) {
        this.p = p;
        this.q = q;
    }

    void display() {
        System.out.println(p + " " + q);
    }
}
