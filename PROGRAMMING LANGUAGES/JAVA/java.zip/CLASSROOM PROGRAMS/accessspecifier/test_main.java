public class test_main {
    public static void main(String[] args) {
        test_private t1=new test_private();
        System.out.println(t1.get_x());
    }
    
}
