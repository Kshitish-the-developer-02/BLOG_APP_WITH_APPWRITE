public class c {
    int x;

    void input_x(int x) {
        this.x = x;

    }
    void display_x() {
        System.out.println(x);
    }

}
