public class test_main {
    public static void main(String[] args) {
        test t=new test();
        t.display();
    }
    
}
