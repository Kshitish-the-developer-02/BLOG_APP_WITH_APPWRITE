public class program_3 {
   static final double pi=3.14;
    public static void main(String[] args) {
       //formula for finding volume of sphere is
       // 4/3 pi*r^3

       double r=10;

       double volume;
       volume =4/3*pi*r*r*r;

       System.out.println(" volume of the sphere is= "+volume);
    }

}
