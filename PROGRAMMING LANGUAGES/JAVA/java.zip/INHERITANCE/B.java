public class B extends A {
    int y=20;
    void display(){
        // super.display();
        System.out.println(super.x);
        System.out.println(y);
    }
}
