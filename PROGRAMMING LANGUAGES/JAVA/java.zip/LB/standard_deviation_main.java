
public class standard_deviation_main {
    public static void main(String[] args) {
        standard_deviation dev =new standard_deviation();
        double result=dev.standardDeviation();
        System.out.print("standard deviation of the array is:  "+result);
    }
}


        
