public class cmain {
    public static void main(String[] args) {
        c1 obj=new c1();
        obj.input_x(10);
        obj.display_x();
        obj.input_y(20);
        obj.display_y();

    }
    
}
