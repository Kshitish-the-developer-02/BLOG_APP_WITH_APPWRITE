public class demo2_main {
    public static void main(String[] args) {
        demo2 d=new demo2(8, 9);
        d.display();
    }
    
}
