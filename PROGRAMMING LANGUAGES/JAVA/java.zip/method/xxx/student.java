// package xxx;

public class student {
    public static void main(String[] args) {
        System.out.println("hrllo");
    }
    
}
