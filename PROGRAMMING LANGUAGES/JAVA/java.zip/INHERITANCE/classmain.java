public class classmain {
    public static void main(String[] args) {
        B obj=new B();
        // obj.display();
        obj.display();
    }
    
}
