/*employee table constraint names */
select constraint_name, constraint_type
from user_constraints
where table_name='EMP_KSH';