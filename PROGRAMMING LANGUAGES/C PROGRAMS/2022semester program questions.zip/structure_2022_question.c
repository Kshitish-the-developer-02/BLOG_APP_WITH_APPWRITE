#include <stdio.h>
#include <string.h>

#define MAX_PLAYERS 50

struct cricket
{
    char player_name[50];
    char team_name[50];
    float batting_average;
};

int main()
{
    struct cricket player[MAX_PLAYERS];
    int i, j, num_players;

    printf("Enter the number of players (max %d): ", MAX_PLAYERS);
    scanf("%d", &num_players);

    // Read information about all players
    for (i = 0; i < num_players; i++)
    {
        printf("\nPlayer %d\n", i + 1);
        printf("Enter player name: ");
        scanf("%s", player[i].player_name);
        printf("Enter team name: ");
        scanf("%s", player[i].team_name);
        printf("Enter batting average: ");
        scanf("%f", &player[i].batting_average);
    }

    // Print team-wise list of players with batting average
    printf("\nTeam-wise list of players with batting average:\n");

    for (i = 0; i < num_players; i++)
    {
        // Check if we've already printed this team
        int team_printed = 0;
        for (j = 0; j < i; j++)
        {
            if (strcmp(player[i].team_name, player[j].team_name) == 0)
            {
                team_printed = 1;
                break;
            }
        }
        if (team_printed)
        {
            continue;
        }

        // Print the team name
        printf("\nTeam: %s\n", player[i].team_name);

        // Print the players and their batting averages for this team
        for (j = 0; j < num_players; j++)
        {
            if (strcmp(player[i].team_name, player[j].team_name) == 0)
            {
                printf("%s, %.2f\n", player[j].player_name, player[j].batting_average);
            }
        }
    }
    return 0;
}
