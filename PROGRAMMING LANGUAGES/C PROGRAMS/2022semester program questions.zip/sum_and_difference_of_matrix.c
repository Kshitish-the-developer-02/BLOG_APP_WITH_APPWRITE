#include <stdio.h>

#define MAX_ROWS 100
#define MAX_COLS 100

int main() {
    int matrix[MAX_ROWS][MAX_COLS];
    int m, n, i, j;
    int diagonal_sum = 0, first_row_sum = 0;
    
    // Input matrix dimensions
    printf("Enter the number of rows and columns (m n): ");
    scanf("%d %d", &m, &n);
    
    // Input matrix elements
    printf("Enter the matrix elements:\n");
    for (i = 0; i < m; i++) {
        for (j = 0; j < n; j++) {
            scanf("%d", &matrix[i][j]);
        }
    }
    
    // Calculate diagonal sum and first row sum
    for (i = 0; i < m; i++) {
        for (j = 0; j < n; j++) {
            if (i == j) {
                diagonal_sum += matrix[i][j];
            }
            if (i == 0) {
                first_row_sum += matrix[i][j];
            }
        }
    }
    
    // Print the difference between diagonal sum and first row sum
    printf("Difference between diagonal sum and first row sum: %d\n", diagonal_sum - first_row_sum);
    
return 0;
}
