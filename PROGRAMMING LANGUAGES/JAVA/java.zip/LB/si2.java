public class si2 extends si1 {
    
    int y=20;
    void display()
    {
        System.out.println(y);
    }
}
    

