#include <stdio.h>

#define MAX_SIZE 100

int main()
{
    int matrix[MAX_SIZE][MAX_SIZE];
    int sparse[MAX_SIZE][3]; // array to store sparse matrix
    int m, n, i, j, count = 0;

    printf("Enter the number of rows of matrix:  ");
    scanf("%d", &m);
    printf("Enter the number of columns of matrix:  ");
    scanf("%d", &n);

    printf("Enter the elements of the matrix: \n");
    for (i = 0; i < m; i++)
    {
        for (j = 0; j < n; j++)
        {
            scanf("%d", &matrix[i][j]);
            if (matrix[i][j] != 0)
            {
                sparse[count][0] = i;
                sparse[count][1] = j;
                sparse[count][2] = matrix[i][j];
                count++;
            }
        }
    }


    printf("\noroginal matrix is:\n");
    for (i = 0; i < m; i++)
    {
        for (j = 0; j < n; j++)
        {
            printf("%d\t", matrix[i][j]);
        }
        printf("\n");
    }

    // printing the sparse matrix
    printf("\nSparse matrix representation:\n");
    printf("Row\tColumn\tValue\n");
    for (i = 0; i < count; i++)
    {
        printf("%d\t%d\t%d\n", sparse[i][0], sparse[i][1], sparse[i][2]);
    }
    return 0;
}