public class program_4 {
    public static void main(String[] args){
        
        double temp=95;  //this temperature is in celcious
        double far;

        far=(temp*9/5)+32;

        System.out.println(temp + " degree celcious is = "+far+" farenhit");
    }
    
}
