public class literals {
    public static void main(String[] args) {
        byte age = 20;
        int age1 = 22;
        short age3 = 25;
        long age4 = 1111111111111111l; // instead of small l we also use caital L
        char ch = 'a';
        float f = 5.6f; // instead of small f we also use caital F
        double d = 96.5d; // instead of small d we also use caital D but it's not necessary because it is
                          // default float literal
        boolean bool = true;
        String str = "kshitish";
        System.out.println(age);
        System.out.println(age1);
        System.out.println(age3);
        System.out.println(age4);
        System.out.println(ch);
        System.out.println(f);
        System.out.println(d);
        System.out.println(bool);
        System.out.println(str);

    }

}
