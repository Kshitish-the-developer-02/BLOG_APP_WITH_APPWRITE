public class program_1{
    public static void main(String[] args)
    {
        System.out.println("hello kshitish!....this is the first program");
    }
}