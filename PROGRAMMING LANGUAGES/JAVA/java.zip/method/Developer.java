
class Developer implements Employee {
    public void get_sallary() {
        System.out.println("salary of the developer :50000");
    }
}
