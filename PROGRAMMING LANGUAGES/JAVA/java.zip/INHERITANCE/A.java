public class A {
    int x = 10;
    void display() {
        System.out.println(x);
    }
}
