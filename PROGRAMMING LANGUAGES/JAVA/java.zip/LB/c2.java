public class c2 extends c1 {
    int y;
    void input_y(int y)
    {
        this.y=y;
    }
    void display()
    {
        System.out.println(y);
    }
    
}
