class c1 extends c{
    int y;
    void input_y(int y){
   

     this.y=y;
    }
    void display_y(){
        System.out.println(y);
    }
}