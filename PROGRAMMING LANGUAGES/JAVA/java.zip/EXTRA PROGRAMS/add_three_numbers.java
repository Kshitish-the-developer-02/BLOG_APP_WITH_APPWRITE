public class add_three_numbers {

    public static void main(String[] args) {
        System.out.println("sum of three numbers is");

        int num1 = 10;
        int num2 = 20;
        int num3 = 30;
        int sum = num1 + num2 + num3;
        System.out.println(sum);

    }

}
