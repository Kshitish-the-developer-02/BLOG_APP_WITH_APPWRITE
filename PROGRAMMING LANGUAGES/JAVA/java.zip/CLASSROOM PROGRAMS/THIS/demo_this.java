public class demo_this {
    public static void main(String[] args) {
        demo d=new demo();
        d.input(5, 8);
        d.display();
    }
    
}
