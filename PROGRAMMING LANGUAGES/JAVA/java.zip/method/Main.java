public class Main{
    public static void main(String[] args) {
        Developer dev=new Developer();
        Manager mng=new Manager();
    
        dev.get_sallary();
        mng.get_sallary();
        
    }
}