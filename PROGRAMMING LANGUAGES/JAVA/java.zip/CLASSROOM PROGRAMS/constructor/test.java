public class test {
    int x;
    test(){
        x=96;
    }
    void display(){
        System.out.println(x);
    }
}
