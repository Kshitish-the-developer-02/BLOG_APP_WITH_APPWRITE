public class testSum {
    public static void main(String[] args) {
        sumDigits sum = new sumDigits();
        sum.input(156);
        sum.display();
    }

}
